﻿using System.Data;

namespace SqlHelperDemo
{
    public interface ISqlHelper
    {
        ConnectionState State { get; }
        void Open();
    }
}