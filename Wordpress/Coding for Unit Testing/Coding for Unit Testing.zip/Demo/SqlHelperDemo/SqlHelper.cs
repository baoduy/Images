﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlHelperDemo
{
    public class SqlHelper : ISqlHelper
    {
        private IDbConnection Connection { get; set; }
        public ConnectionState State => this.Connection.State;

        /// <summary>
        /// Create SqlHelper with connection string.
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        public SqlHelper(string connectionString)
        {
            this.Connection = BuildConnection(connectionString);
        }

        /// <summary>
        /// Create SqlHelper with IDbConnection.
        /// </summary>
        /// <param name="connection">IDbConnection</param>
        public SqlHelper(IDbConnection connection)
        {
            this.Connection = connection;
        }

        public void Open() => this.Connection.Open();

        protected virtual IDbConnection BuildConnection(string connectionString) => new SqlConnection(connectionString);

        //public DataTable ExecuteTable(string query)
        //{
        //    using (var adapter = this.BuildAdapter(query))
        //    {
        //        var data = adapter.FillSchema(new DataTable(), SchemaType.Source);
        //        adapter.Fill(data);
        //        return data;
        //    }
        //}
    }
}