﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.Common;
using Microsoft.QualityTools.Testing.Fakes;
using System.Data.SqlClient.Fakes;
using Moq;
using Moq.Protected;
using System.Data.SqlClient;

namespace SqlHelperDemo.Tests
{
    [TestClass()]
    public class SqlHelperTests
    {
        [TestMethod]
        public void SqlHelper_Contructor_WithReal_ConnectionString_TheOpenState_Test()
        {
            //Create SqlHelper instance with connection string.
            var conn = new SqlHelper("Data Source=localhost;Integrated Security=true;");
            //Open the connection.
            conn.Open();
            //Verify the State value.
            Assert.IsTrue(conn.State == ConnectionState.Open);
        }

        [TestMethod]
        public void SqlHelper_Contructor_WithMsFakes_Test()
        {
            bool isOpenMethodCalled = false;
            bool isSatePropertCalled = false;

            using (ShimsContext.Create())
            {
                //Overwrite Open method of all SqlConnection instances.
                ShimSqlConnection.AllInstances.Open = (SqlConnection) =>
                {
                    //Mark that Open method is called.
                    isOpenMethodCalled = true;
                };
                //Overwrite State property of all SqlConnection instances.
                ShimSqlConnection.AllInstances.StateGet = (SqlConnection) =>
                {
                    //Mark that State property is called.
                    isSatePropertCalled = true;
                    return ConnectionState.Open;
                };

                var conn = new SqlHelper("Data Source=Dummy Server;");
                conn.Open();
                Assert.AreEqual(ConnectionState.Open, conn.State);
            }

            Assert.IsTrue(isOpenMethodCalled);
            Assert.IsTrue(isSatePropertCalled);
        }

        [TestMethod]
        public void SqlHelper_RealInstance_VerifyConnectionProperty_Test()
        {
            //Create SqlHelper with connection.
            var conn = new SqlHelper("Data Source=Dummy Server;");
            //Create PrivateObject to get private property value.
            var priObj = new PrivateObject(conn);
            //Verify the Connection property.
            Assert.IsNotNull(priObj.GetProperty("Connection"));
            Assert.IsNotNull(priObj.GetProperty("Connection")is SqlConnection);
        }

        [TestMethod]
        public void SqlHelper_Constructor_WithMockIDbConnection_Test()
        {
            //Create mock of IDbConnection.
            var dbConnMock = new Mock<IDbConnection>();
            //Mark Open() is verifiable.
            dbConnMock.Setup(d => d.Open()).Verifiable();
            //Implement State to return ConnectionState.Open.
            dbConnMock.Setup(d => d.State).Returns(ConnectionState.Open);

            //Create SqlHelper using the second Constructor method to pass the Mock object in.
            var conn = new SqlHelper(dbConnMock.Object);
            //Execute the test.
            conn.Open();

            //Verify the State.
            Assert.AreEqual(ConnectionState.Open, conn.State);
            //Verify the Open method call.
            dbConnMock.Verify(c => c.Open(), Times.Once());
            //Verify the Sate property call.
            dbConnMock.Verify(c => c.State, Times.Once());
        }

        [TestMethod]
        public void SqlHelper_Constructor_WithConnectionString_Test()
        {
            //Create mock of IDbConnection.
            var dbConnMock = new Mock<IDbConnection>();
            //Mark Open() is verifiable.
            dbConnMock.Setup(d => d.Open()).Verifiable();
            //Implement State to return ConnectionState.Open.
            dbConnMock.Setup(d => d.State).Returns(ConnectionState.Open);

            //Create the mock of SqlHelper with dummy connection string.
            var helperMock = new Mock<SqlHelper>("Data Source=DummyServer;");
            //Orverwrite protected virtual BuildConnection method to return the mock of SqlConnection.
            helperMock.Protected().Setup<IDbConnection>("BuildConnection", ItExpr.IsAny<string>()).Returns(dbConnMock.Object);

            var helper = helperMock.Object;
            //Execute the test.
            helper.Open();

            //Verify the State.
            Assert.AreEqual(ConnectionState.Open, helper.State);
            //Verify BuildConnection method call.
            helperMock.Protected().Verify("BuildConnection", Times.Once(), ItExpr.IsAny<string>());
            //Verify the Open method call.
            dbConnMock.Verify(c => c.Open(), Times.Once());
            //Verify the Sate property call.
            dbConnMock.Verify(c => c.State, Times.Once());
        }
    }
}